sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{Send:function(n){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=Send.js.map